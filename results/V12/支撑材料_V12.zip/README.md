# V12 支撑材料

五份填写完成的 Result 位于 results/V12/附件5。仅含原模板工作表，按当天零点起的144个十分钟区间填写；计算精度保存在单元格中，显示保留两位小数。

压缩包不含题目原始附件。安装 Python 3.12 和 requirements.txt 中的依赖后，在解压根目录运行以下命令（路径替换为本地题目附件位置）。

~~~text
python -m pip install -r requirements.txt
python -m src.v12_results --templates "<C题目录>/附件/附件5"
python -m src.v12_reproduce --data-root "<C题目录>" --days 1
python -m src.v12_reproduce --data-root "<C题目录>"
~~~

第一个运行命令填写并核验已保存的完整结果；第二个复算每个分支的首日，用于快速核验；第三个重新计算全部334天已选定策略，运行时间较长。复算使用冻结的历史月度选择中间结果，不重新开展参数搜索。原始题目文件只读。实际费用按最终合同量和真实交易价格重新核算；普通合同、取消、新增、紧急补购分别计费。

图形数值输入保存在 artifacts/v8/figure_data.mat 与 artifacts/v10/dispatch_distribution.mat。MATLAB R2026a 中：

~~~matlab
addpath('scripts');
v10_figures(pwd,fullfile(pwd,'support','V12'));
v12_figure11(pwd);
~~~

12张图沿用论文已经核验的MATLAB版本；图名中的v10表示图形来源，文稿版本为V12。重新汇总价格—储能功率分布可先执行 python -m src.v10_prepare。

artifacts/v5b 中的 selected_intervals 文件保留全部执行轨迹；versions 文件保留日期、发布时间版本、有效起点、目标区间、修改前后计划，未重复打包可由原始附件与程序生成的预测输入列。文件散列和长度见 MANIFEST.json。
